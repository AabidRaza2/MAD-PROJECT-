package com.example.abidraza47502

import android.content.Intent
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.abidraza47502.Item
import com.example.abidraza47502.ItemListActivity

class MainActivity : AppCompatActivity() {

    private lateinit var itemnameEdittext: EditText
    private lateinit var itemquantityEdittext: EditText
    private lateinit var itempriceEdittext: EditText
    private lateinit var addcart: Button
    private lateinit var itemList: MutableList<Item>
    private lateinit var Checklist: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        itemnameEdittext = findViewById(R.id.itemnameEdittext)
        itemquantityEdittext = findViewById(R.id.itemquantityEdittext)
        itempriceEdittext = findViewById(R.id.itempriceEdittext)
        addcart = findViewById(R.id.addcart)
        Checklist = findViewById(R.id.Checklist)
        itemList = mutableListOf()

        addcart.setOnClickListener {
            val itemName = itemnameEdittext.text.toString()
            val itemQuantity = itemquantityEdittext.text.toString().toInt()
            val itemPrice = itempriceEdittext.text.toString().toDouble()
            val item = Item(itemName, itemPrice, itemQuantity)
            itemList.add(item)

            itemnameEdittext.text.clear()
            itemquantityEdittext.text.clear()
            itempriceEdittext.text.clear()

            Toast.makeText(this, "Item Added", Toast.LENGTH_SHORT).show()
        }

        Checklist.setOnClickListener {
            // Pass the item list to the next activity
            val intent = Intent(this, ItemListActivity::class.java)
            intent.putParcelableArrayListExtra("itemList", ArrayList(itemList))
            startActivity(intent)
        }
    }
}
