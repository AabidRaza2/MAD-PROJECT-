package com.example.abidraza47502

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.abidraza47502.Item
import com.example.abidraza47502.R
import android.widget.TextView

class InvoiceActivity : AppCompatActivity() {

    private lateinit var itemList: List<Item>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_invoice)

        itemList = intent.getParcelableArrayListExtra("itemList") ?: emptyList()

        generateInvoice()
    }

    private fun generateInvoice() {
        val invoiceBuilder = StringBuilder()

        invoiceBuilder.append("Invoice\n\n")

        var totalAmount = 0.0

        for (item in itemList) {
            val itemName = item.name
            val itemPrice = item.price
            val itemQuantity = item.quantity
            val itemAmount = itemPrice * itemQuantity

            invoiceBuilder.append("Item: $itemName\n")
            invoiceBuilder.append("Price: $itemPrice\n")
            invoiceBuilder.append("Quantity: $itemQuantity\n")
            invoiceBuilder.append("Amount: $itemAmount\n\n")

            totalAmount += itemAmount
        }

        invoiceBuilder.append("Total Amount: $totalAmount\n")

        val invoiceTextView: TextView = findViewById(R.id.invoiceTextView)
        invoiceTextView.text = invoiceBuilder.toString()
    }
}
