package com.example.abidraza47502

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class List_activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
    }
}